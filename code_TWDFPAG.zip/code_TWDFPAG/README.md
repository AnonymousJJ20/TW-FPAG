## Description
- Matlab code for the paper: "Tensor Wheel Completion with Low-Rank Factor prior and Adaptive Graph Regularizer for Hyperspectral Image Recovery", 
submitted to IEEE Transactions on Multimedia.


## Get started
- Directly run: ``Demo_s7.m`` for an example on Scence 7 data.
 

## Contact
If interested, feel free to email me at <tianxin1307@hnu.edu.cn>.
