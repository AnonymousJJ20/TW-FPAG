

%% =================================================================

load('simu_DC60.mat')
X = simu_DC60;

% load('simu_pavia.mat')
% X = simu_pavia;

% load('S7.mat')
% X = XT;

% load('simu_flowers.mat')
% X = simu_flowers;

% load('simu_feathers.mat')
% X = simu_feathers;

% load('simu_toy.mat')
% X = simu_toy;

% load('simu_balloons.mat')
% X = simu_balloons;


% load('simu_oil.mat')
% X = simu_oil;

% load('simu_beads.mat')
% X = simu_beads;

% load('simu_cloth.mat')
% X = simu_cloth;

% load('simu_peppers.mat')
% X = simu_peppers;

% load('simu_face.mat')
% X = simu_face;

% load('simu_lemons.mat')
% X = simu_lemons;

% load('simu_lemonslices.mat')
% X = simu_lemonslices;

X(X<0) = 0;
if max(X(:))>1
    X = X/max(X(:));
end


%% 
sample_ratio = 0.10;
fprintf('### Performing SR: %4.2f ###\n', sample_ratio);
Y_tensor = X;
clear X
Ndim = ndims(Y_tensor);
Nway = size(Y_tensor);
rand('seed',2);
Omega = find(rand(prod(Nway),1)<sample_ratio);
Y_init = initialization_M(Nway, Omega, Y_tensor(Omega));

%% Miss_Data
F = zeros(Nway);
F(Omega) = Y_tensor(Omega);

%% Perform TW-TC Algorithm
    opts = [];
    opts.tol   = 1e-5;
    opts.maxit = 1000;
    opts.rho   = 0.001;
    opts.Xtrue = Y_tensor;
    opts.R = [3, 15, 3; % R_i
              3, 3, 3]; % L_i      
    
    F = Y_init;
    
%% ------------------------------------------------------------------------    
if isfield(opts, 'tol');         tol   = opts.tol;              end
if isfield(opts, 'maxit');       maxit = opts.maxit;            end
if isfield(opts, 'rho');         rho   = opts.rho;              end
if isfield(opts, 'R');           max_R = opts.R;                end
%
num_padarray = 2;
R = max(max_R-num_padarray, 2);
Ndim = ndims(F); 
Nway = size(F);
X = F;
%
Factors_dims = factor_dims(Nway, R);
Max_Factors_dims = factor_dims(Nway, max_R);
rng('default')
%
G = cell(Ndim,1);
for i=1:Ndim
    G{i}=rand(Factors_dims(i,:));
end
Core = rand(R(2,:));
C_old = Core;
Out.RSE = [];
r_change = 0.0005;
%
for k = 1:maxit
    X_old = X;
    % Update G_k, k=1,2,...,N.
    for num = 1:Ndim
        GCrest = tenremat(circ_tnprod_rest(G,Core,num), Ndim);  % Q is the right part of the relation equation
        TempA  = tenmat_sb(X,num)*GCrest'+rho*my_Unfold(G{num},size(G{num}),2);
        TempB  = (GCrest*GCrest')+rho*eye(size(GCrest,1),size(GCrest,1));
        G{num} = my_Fold(TempA*pinv(TempB),size(G{num}),2);
    end
    % Update the core tensor C.
    Girest = tnreshapemat(order_tnprod_rest(G), Ndim);
    if k==1  ||  numel(Core)>numel(C_old)  ||  ( k>200 && mod(k, 20)==0 )   
        TempC = reshape(X,[1,prod(Nway)])*Girest'+rho*reshape(Core,[1,numel(Core)]);
        TempD = (Girest*Girest')+rho*eye(size(Girest,1),size(Girest,1));
        TempE = TempC*pinv(TempD);
        Core = reshape(TempE,size(Core));
    end
    % Update X 
    X = (reshape(TempE*Girest,Nway)+rho*X_old)/(1+rho);
    X(Omega) = F(Omega);
    %% check the convergence
     rse = norm(X(:)-X_old(:)) / norm(X_old(:));
%     Out.RSE = [Out.RSE, rse];
    
%     if k == 1 || mod(k, 20) == 0
%         fprintf('inc_TW-TC: iter = %d   RSE=%.10f   \n', k, rse);
%     end

   [mpsnr,mssim,ergas] = msqia(Y_tensor, X);
    msa = MSA(Y_tensor,X);
    fprintf('iter %d mpsnr= %f mssim= %f ergas= %f msa= %f\n',k,mpsnr,mssim,ergas,msa);

    if rse < tol 
        break;
    end
    
    C_old = Core;
    rank_inc = double(Factors_dims<Max_Factors_dims);
    if rse<r_change && sum(rank_inc(:))~=0
        [G, Core] = rank_inc_adaptive(G, Core, rank_inc, Ndim);
        Factors_dims  = Factors_dims+rank_inc;
        r_change = r_change*0.1;
    end
end
    
    
    
    
    
    
    
    
    
 



 