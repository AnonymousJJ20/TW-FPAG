
%% Demo

load('S7.mat')
X = XT;
 
sample_ratio = 0.25;
fprintf('### Performing SR: %4.2f ###\n', sample_ratio);
T = X;
clear X
Nway = size(T);
Ndim = ndims(T); 
rand('seed',2);
Omega = find(rand(prod(Nway),1)<sample_ratio);

%% Miss_Data
% Observe = zeros(Nway);
% Observe(Omega) = T(Omega);

%% parameters
opts=[];
opts.Nway = Nway;
opts.Ndim = Ndim;
opts.lamda = 0.1;
opts.mu = 0.01;   %0.001
opts.max_R = [15, 15, 15; % R_i
               7,  7,  7];    % L_i          
opts.topk  = 4*ones(Ndim,1);
opts.maxit = 1500;
opts.tol   = 1e-5;
    
    
X = TWDFPAG(T, Omega, opts);    


[mpsnr,mssim,ergas] = msqia(T, X);
msa = MSA(T,X);


    
    
    
    
    
    
    
    
    
 



 