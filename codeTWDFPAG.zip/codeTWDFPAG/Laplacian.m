

function [L,D,W] = Laplacian(X, topk)
                                                             
    tsize = size(X);
    dis = zeros(tsize(2));               
    for i=1:tsize(2)
      for j=1:tsize(2)
          a = X(:,i);
          b = X(:,j);
          dis(i,j)= norm(a-b,'fro'); 
      end
    end                  

    W = zeros(tsize(2));     
    for j = 1:tsize(2)
        tmp = dis(:,j);  
        [~, neighbors] = sort(tmp, 'ascend'); 
        neighbors = neighbors(1:topk); 
        W(neighbors, j) = 1;  
        W(j, j) = 0;        
    end

    
    for i=1:tsize(2)
        for j = 1:tsize(2)
            if W(i,j) ~= W(j,i)
               W(i,j) = 0;
               W(j,i) = 0;      
            end
        end
    end 

%     D = diag(sum(W,2));   
   D = diag(sum(W,1));     

    L = D-W;
end
    
    
    






