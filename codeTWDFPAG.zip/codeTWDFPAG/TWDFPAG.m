

function X = TWDFPAG(T, Omega, opts)   

   Nway= opts.Nway;
   Ndim = opts.Ndim;
   lamda = opts.lamda;
   mu = opts.mu;  
   max_R = opts.max_R;              
   topk = opts.topk;
   maxit = opts.maxit;
   tol = opts.tol;
   
rho   = 1e-3; 
t     = 1.01;  
num_padarray = 2;
R = max(max_R-num_padarray, 2);

Y_init = initialization_M(Nway, Omega, T(Omega));

% Observe = zeros(Nway);
% Observe(Omega) = T(Omega);
% Y_init = Observe;

X = Y_init;

Factors_dims = factor_dims(Nway, R);
rng('default')
%
G = cell(Ndim,1);
for num=1:Ndim
    G{num}=rand(Factors_dims(num,:));
end

K = cell(Ndim,1);
for num=1:Ndim
    K{num}=rand(Factors_dims(num,:));
end

F = G; 

K = G; 

Y = cell(Ndim,1);
for n=1:Ndim
    Y{n}=zeros(Factors_dims(n,:));
end

Z = cell(Ndim,1);
for n=1:Ndim
    Z{n}=zeros(Factors_dims(n,:));
end

Core = rand(R(2,:));

for k = 1:maxit
    X_old = X;
    
    % Update K_n, n=1,2,...,N.   
        for n=1:Ndim
            tempH = my_Unfold(G{n},size(G{n}),2);
            tempI = my_Unfold(Z{n},size(Z{n}),2);
            [L{n},~,~] = Laplacian(tempH', topk(n)); 
            sizeLn = size(L{n});
            tempJ=(mu*L{n}' + mu*L{n} + rho * eye(sizeLn))\(rho * tempH - tempI);
            K{n} = my_Fold(tempJ, size(K{n}), 2);
        end
    
    
    
    % Update G_n, n=1,2,...,N.
    for n = 1:Ndim      
        GCrest = tenremat(circ_tnprod_rest(G,Core,n), Ndim);  
        TempA  = tenmat_sb(X,n)*GCrest'+rho*my_Unfold(F{n},size(F{n}),2)+my_Unfold(Y{n},size(Y{n}),2)+rho*my_Unfold(K{n},size(K{n}),2)+my_Unfold(Z{n},size(Z{n}),2);
        TempB  = (GCrest*GCrest')+2*rho*eye(size(GCrest,1),size(GCrest,1));
        G{n} = my_Fold(TempA*pinv(TempB),size(G{n}),2);
    end
    
    % Update the core tensor C.
    Girest = tnreshapemat(order_tnprod_rest(G), Ndim);
    TempC = reshape(X,[1,prod(Nway)])*Girest';
    TempD = (Girest*Girest');
    TempE = TempC*pinv(TempD);
    Core = reshape(TempE,size(Core));

   % Update F +
   for n = 1:Ndim
     tempF = my_Unfold(G{n},size(G{n}),2) - my_Unfold(Y{n},size(G{n}),2)/rho;
     tempG = lamda/rho;
     f     = SVT(tempF, tempG, 0);     
     F{n} = my_Fold(f,size(F{n}),2);    
   end
    
    % Update X 
    X = reshape(TempE*Girest,Nway);
    X(Omega) = Y_init(Omega);
    
    
    
    % Update Y 
    for n = 1:Ndim
        Y{n} =  Y{n} + rho*(F{n} - G{n});     
    end
    
    % Update Z 
    for n = 1:Ndim
        Z{n} =  Z{n} + rho*(K{n} - G{n});     
    end
    
    rho = t*rho;
    
    
    %% check the convergence
     rse = norm(X(:)-X_old(:)) / norm(X_old(:));

   [mpsnr,mssim,ergas] = msqia(T, X);
    msa = MSA(T,X);
    fprintf('iter %d mpsnr= %f mssim= %f ergas= %f msa= %f\n',k,mpsnr,mssim,ergas,msa);
    
    if rse < tol 
        break;
    end
    
end